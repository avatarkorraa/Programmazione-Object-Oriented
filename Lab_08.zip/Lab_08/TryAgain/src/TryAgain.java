import java.util.*;

public class TryAgain {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        double sum = 0;

        int t = 0;

        while(true) {

            System.out.println("Dammi dei numeri:");

            try {

                sum += in.nextDouble();
                t = 0;

            }

            catch (InputMismatchException ime) {

                t++;
                System.out.println("Input errat! Riprova!");

            }

            finally {

                in.nextLine();

            }

            if(t > 2)
                break;

        }

        System.out.println("Il totale dei valori inseriti è " + sum);
    }
}