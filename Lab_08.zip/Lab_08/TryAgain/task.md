# Prova Ancora

Scrivere un programma che chieda all’utente di inserire un insieme di double.

Quando viene inserito un valore che non è un numero, date all’utente una seconda possibilità di introdurre un valore
corretto e, dopo due tentativi, fate terminare il programma.

Sommate tutti i valori che sono stati specificati in modo corretto e, quando l’utente ha terminato di inserire i dati,
visualizzate il totale.

Usate la gestione delle eccezioni per identificare i valori di ingresso non validi.