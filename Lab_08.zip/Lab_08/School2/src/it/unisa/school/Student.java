package it.unisa.school;

import java.util.AbstractMap;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;

public class Student extends Person {

    public Hashtable<String, Integer> students;
    private int numberOfAbsences;
    private String matricola;

    public Student(String name, String surname, int birthYear, String userId, String password, String matricola, int numberOfAbsences) {
        super(name, surname, birthYear, userId, password);

        if(matricola.isEmpty() || matricola == null)
            throw new IllegalArgumentException("Matricola dello studente con formato errato");

        this.matricola = matricola;
        this.numberOfAbsences = numberOfAbsences;
        this.students = new Hashtable<>();
    }

    public String getStudentId(){

        return this.matricola;

    }

    public void addAbsence() {
        this.numberOfAbsences++;
    }

    public void removeAbsence() {
        this.numberOfAbsences--;
    }

    public int getNumberOfAbsences() {
        return numberOfAbsences;
    }

    public void addExam(String examName, int grade) {

        if(grade < 18 || grade > 31)
            throw new IllegalArgumentException("Voto non valido (minore di 18 o maggiore di 30 e lode)");

        students.put(examName, grade);
    }

    public int getNumberOfPassedExams() {

        return students.size();

    }

    public Hashtable<String, Integer> getPassedExam(){

        return students;

    }

    public double getAverageGrade() {

        if(students.size() == 0)
            return 0;

        int sum  = 0;
        double averageGrade;

        for(int temp:  students.values()){

            if(temp == 31)
                temp--;

            sum += temp;

        }

        averageGrade = sum / students.size();

        return averageGrade;

    }

    @Override
    public String toString() {
        return super.toString() +
                ", Numero di assenze=" + numberOfAbsences;
    }
}
