package it.unisa.school;

import org.junit.Assert;
import org.junit.Test;

public class StudentTest {

    @Test
    public void toStringTest() {
        Student s = new Student("Roberto", "Bianchi", 2005, "robbia", "testPassword", "0522500103", 3);
        Assert.assertEquals("Nome='Roberto', Cognome='Bianchi', Anno di nascita=2005, Numero di assenze=3",
                s.toString());
    }

    @Test(expected = IllegalArgumentException.class)

    public void wrongMatricola(){

        Student s =  new Student("Roberto", "Bianchi", 2005, "robbia", "testPassword", "", 3);

    }

    @Test(expected = IllegalArgumentException.class)

    public void wrongExamValue(){

        Student s = new Student("Roberto", "Bianchi", 2005, "robbia", "testPassword", "0522500103", 3);

        s.addExam("Biologia", 32);
        s.addExam("Scienze chimiche 1", 17);

    }

    @Test

    public void examAverageGrade(){

        Student s = new Student("Roberto", "Bianchi", 2005, "robbia", "testPassword", "0522500103", 3);

        s.addExam("Biologia", 25);
        s.addExam("Biologia 2", 31);
        s.addExam("Analisi 1", 28);

        Assert.assertEquals(27, s.getAverageGrade(), 0);

    }

    @Test

    public void examNumber(){

        Student s = new Student("Roberto", "Bianchi", 2005, "robbia", "testPassword", "0522500103", 3);

        s.addExam("Biologia", 25);
        s.addExam("Biologia 2", 31);
        s.addExam("Analisi 1", 28);

        Assert.assertEquals(3, s.getNumberOfPassedExams(), 0);

    }

}