# Bank 3

Modificare la classe `BankAccount` in modo che lanci un’eccezione quando viene istanziato un conto con saldo negativo,
quando viene versata una somma negativa e quando si tenta di prelevare una somma non compresa tra zero e il saldo del
conto.

Un’eccezione deve essere controllata e le altre non controllate.

Aggiornare i test case per verificare che le eccezioni siano lanciate.