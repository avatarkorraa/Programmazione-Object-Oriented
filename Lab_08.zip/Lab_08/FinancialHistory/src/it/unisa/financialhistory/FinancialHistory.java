package it.unisa.financialhistory;

import java.util.ArrayList;
import java.util.IllformedLocaleException;
import java.util.List;

public class FinancialHistory {
    final private Person person;
    private double balance;
    final private List<Movement> movements;

    public FinancialHistory(Person person, double balance) {

        if(balance < 0)
            throw(new IllegalArgumentException("bilancio in rosso"));

        this.person = person;
        this.balance = balance;
        movements = new ArrayList<>();

    }

    public void receiveFrom(int amount, String source) {

        balance += amount;
        this.movements.add(new Movement(source, amount));

    }

    public void spendFor(int amount, String reason) {

        if(amount > this.balance)
            throw(new IllegalArgumentException("bilancio in rosso"));

        balance -= amount;
        this.movements.add(new Movement(reason, amount));

    }

    public double cashOnHand() {

        return this.balance;

    }

    public double totalReceivedFrom(String source) {

        double total = 0;

        for(Movement e : movements){

            if(source.equals(e.getDescription()))
                total += e.getAmount();

        }

        return total;

    }

    public double totalSpentFor(String reason) {

        double total = 0;

        for(Movement e : movements){

            if(reason.equals(e.getDescription()))
                total += e.getAmount();

        }

        return total;

    }

    public void printMovements() {

        for(Movement e : movements){

            if(e.getAmount() < 0){

                System.out.println("uscita: " + e.getAmount());
                System.out.println("motivo: " + e.getDescription());

            }

            else{

                System.out.println("entrata: " + e.getAmount());
                System.out.println("motivo: " + e.getAmount());

            }

        }

    }

}
