package SMS;

import org.junit.Assert;
import org.junit.Test;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

public class SMSOrganizerTest {

    @Test
    public void testListByDate() {
        SMSOrganizer smsOrganizer = new SMSOrganizer();
        SMS sms1 = new SMS("Dario", new GregorianCalendar(2022, Calendar.OCTOBER, 16, 15, 1), "Ciao");
        SMS sms2 = new SMS("Anna", new GregorianCalendar(2022, Calendar.OCTOBER, 16, 15, 2), "Ciao");
        smsOrganizer.addSMSToOrganizer(sms1);
        smsOrganizer.addSMSToOrganizer(sms2);
        List<SMS> messages = smsOrganizer.getListByDate();
        Assert.assertEquals("Dario", messages.get(0).getSender());
        Assert.assertEquals("Anna", messages.get(1).getSender());
    }

    @Test
    public void testListBySender() {
        SMSOrganizer smsOrganizer = new SMSOrganizer();
        SMS sms1 = new SMS("Dario", new GregorianCalendar(2022, Calendar.OCTOBER, 16, 15, 1), "Ciao");
        SMS sms2 = new SMS("Anna", new GregorianCalendar(2022, Calendar.OCTOBER, 16, 15, 2), "Ciao");
        smsOrganizer.addSMSToOrganizer(sms1);
        smsOrganizer.addSMSToOrganizer(sms2);
        List<SMS> messages = smsOrganizer.getListBySender();
        Assert.assertEquals("Anna", messages.get(0).getSender());
        Assert.assertEquals("Dario", messages.get(1).getSender());
    }

    public static void main(String[] args){

        SMSOrganizer smsOrganizer = new SMSOrganizer();
        SMS sms = new SMS("Nicola", new GregorianCalendar(2022, Calendar.OCTOBER, 26, 16, 2), "Ciao Mario");
        SMS sms1 = new SMS("Mario", new GregorianCalendar(2022, Calendar.OCTOBER, 26, 17, 55), "Ciao Nicola");

        smsOrganizer.addSMSToOrganizer(sms);
        smsOrganizer.addSMSToOrganizer(sms1);

        List <SMS> nuova = smsOrganizer.getListByDate();

        System.out.println("Stampo l'agenda organizzata per data: ");

        for(SMS s: nuova){

            System.out.println("mittente: " + s.getSender() + " data e ora: " + s.getDate().get(Calendar.DATE)
                    + " " + s.getDate().get(Calendar.HOUR) + " ID: " + s.getID() + " Testo: " + s.getText());

        }

        List <SMS> nuova1 = smsOrganizer.getListBySender();

        System.out.println("Stampo l'agenda organizzata per mittente: ");

        for(SMS s: nuova1){

            System.out.println("mittente: " + s.getSender() + " data e ora: " + s.getDate().get(Calendar.DATE)
                    + " " + s.getDate().get(Calendar.HOUR) + " ID: " + s.getID() + " Testo: " + s.getText());

        }

    }

}
