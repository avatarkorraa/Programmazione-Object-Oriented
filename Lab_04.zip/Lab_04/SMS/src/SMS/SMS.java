package SMS;

import java.util.GregorianCalendar;

public class SMS {

  public String mittente;
  public String text;
  public GregorianCalendar data;
  public int ID;
  private static int numeroMessaggi = 0;

  public SMS(String mittente, GregorianCalendar data, String text){

      this.mittente = mittente;
      this.data = data;
      this.text = text;
      this.numeroMessaggi++;
      this.ID = numeroMessaggi;

  }

  public GregorianCalendar getDate(){

      return this.data;

  }

  public String getSender(){

      return this.mittente;

  }

  public String getText(){

      return this.text;

  }

  public int getID(){

      return this.ID;

  }

}