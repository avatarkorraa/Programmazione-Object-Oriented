package SMS;

import java.util.ArrayList;
import java.util.List;

public class SMSOrganizer {

    public List<SMS> sms;

    public SMSOrganizer(){

        this.sms = new ArrayList<>();

    }

    public void addSMSToOrganizer(SMS sms){

        this.sms.add(sms);

    }

    public List getListByDate(){

        SMS minimo, temp;

        if(!this.sms.isEmpty())
            minimo = this.sms.get(0);
        else
            return null;

        for(SMS s: this.sms){

            if(minimo.getDate().compareTo(s.getDate()) > 0){

                temp = this.sms.set(this.sms.indexOf(s), minimo);
                this.sms.set(this.sms.indexOf(minimo), temp);
                minimo = temp;

            }

        }

        return this.sms;

    }

    public List getListBySender(){

        SMS minimo, temp;

        if(!this.sms.isEmpty())
            minimo = this.sms.get(0);
        else
            return null;

        for(SMS s: this.sms){

            if(minimo.getSender().compareTo(s.getSender()) > 0){

                temp = this.sms.set(this.sms.indexOf(s), minimo);
                this.sms.set(this.sms.indexOf(minimo), temp);

            }

        }

        return this.sms;

    }

}
