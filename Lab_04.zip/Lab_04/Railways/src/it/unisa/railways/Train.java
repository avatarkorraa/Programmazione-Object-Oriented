package it.unisa.railways;

import java.util.List;

public class Train {

    private TrainStop partenza;
    private TrainStop arrivo;
    private List fermate;
    private static int posti;
    private int km;

    public Train(TrainStop stazionePartenza, TrainStop stazioneArrivo, List stazioniFermata, int posti, int km){

        partenza = stazionePartenza;
        arrivo = stazioneArrivo;
        fermate = stazioniFermata;
        this.posti = posti;
        this.km = km;

    }

    public int getTotalNumberOfStops(){

        return fermate.size() + 2;

    }

    public double computeMaxRevenues(double prezzo){

        return prezzo * posti * km;

    }

}