package it.unisa.railways;

import java.util.List;

public class ExpressTrain{

    private TrainStop partenza;
    private TrainStop arrivo;
    private List fermate;
    private static int posti;
    private int km;
    private static int postiRistorazione;

    public ExpressTrain(TrainStop stazionePartenza, TrainStop stazioneArrivo, List stazioniFermate, int posti, int postiRistorazione, int km){

        partenza = stazionePartenza;
        arrivo = stazioneArrivo;
        fermate = stazioniFermate;
        this.posti = posti;
        this.km = km;
        this.postiRistorazione = postiRistorazione;

    }

    public int getTotalNumberOfStops(){

        return fermate.size() + 2;

    }

    public double computeMaxRevenues(double prezzo, double prezzoRistoro){

        return ((prezzo * posti) + (prezzoRistoro * postiRistorazione)) * km;

    }


}
