import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class CarSeller {
    private final List<Car> cars;

    public CarSeller() {
        this.cars = new ArrayList<>();
    }

    public void getDataFromFile(File file) throws FileNotFoundException{

        Scanner sf = new Scanner(file);
        String marca, modello;
        int anno;
        double prezzo;

        while(sf.hasNextLine()){

            marca = sf.nextLine();
            modello = sf.nextLine();
            anno = Integer.parseInt(sf.nextLine());
            prezzo = Double.parseDouble(sf.nextLine());

            Car car = new Car(marca, modello, anno, prezzo);
            cars.add(car);

        }

    }

    public boolean searchCar(String marca, String modello){

        boolean flag = false;

        for(Car c: cars){

            if(marca.equals(c.getBrand()))
                flag = true;

            if(flag)
                break;

        }

        if(!flag)
            return false;

        for(Car c: cars){

            if(modello.equals(c.getModel()))
                return flag;

        }

        return false;

    }

    public boolean searchCar(String marca, String modello, int annoImmatricolazione){

        boolean flag = this.searchCar(marca, modello);

        if(!flag)
            return false;

        for(Car c: cars){

            if(marca.equals(c.getBrand()) && modello.equals(c.getModel()) && annoImmatricolazione >= c.getManufacturingYear())
                return flag;

        }

        return false;

    }

    public boolean searchCar(String marca, String modello, double prezzo){

        boolean flag = this.searchCar(marca, modello);

        if(!flag)
            return false;

        for(Car c: cars){

            if(marca.equals(c.getBrand()) && modello.equals(c.getModel()) && prezzo <= c.getPrice())
                return flag;

        }

        return false;

    }

}