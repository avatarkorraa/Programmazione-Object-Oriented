import org.junit.Assert;
import org.junit.Test;

import java.io.File;
import java.io.FileNotFoundException;
import java.nio.file.Path;
import java.util.List;

public class CarSellerTest {

    @Test

    public void FirstSearchTest() throws FileNotFoundException{

        CarSeller carseller = new CarSeller();
        File file = Path.of("test/").resolve("testData.txt").toFile();

        carseller.getDataFromFile(file);

        Assert.assertTrue(carseller.searchCar("Tesla", "Model Y"));

    }

    @Test

    public void SecondSearchTest() throws FileNotFoundException{

        CarSeller carseller = new CarSeller();
        File file = Path.of("test/").resolve("testdata.txt").toFile();

        carseller.getDataFromFile(file);

        Assert.assertTrue(carseller.searchCar("Fiat", "Punto", 2005));

    }

    @Test

    public void ThirdSearchTest() throws FileNotFoundException{

        CarSeller carseller = new CarSeller();
        File file = Path.of("test/").resolve("testData.txt").toFile();
        double prezzo = 60000;

        carseller.getDataFromFile(file);

        Assert.assertTrue(carseller.searchCar("Tesla", "Model Y", prezzo));

    }


}