import java.util.ArrayList;
import java.util.List;

public class Bank {

    private final List<BankAccount> accounts;

    public Bank() {
        this.accounts = new ArrayList<>();
    }

    public void addAccount(double initialBalance, String customerName) {

        BankAccount bankaccount = new BankAccount(initialBalance, customerName);

        accounts.add(bankaccount);

    }

    public BankAccount find(int accountNumber) {

        for (BankAccount ba : this.accounts) {
            if (ba.getAccountNumber() == accountNumber)
                return ba;
        }
        return null;
    }

    public void deposit(int accountNumber, double amount) {

        BankAccount temp;

        temp = this.find(accountNumber);
        temp.deposit(amount);

    }

    public void withdraw(int accountNumber, double amount) {

        BankAccount temp;

        temp = this.find(accountNumber);
        temp.withdraw(amount);

    }

    public double getBalance(int accountNumber) {

        BankAccount temp;

        temp = this.find(accountNumber);
        return temp.getBalance();

    }

    public void transfer(int fromAccountNumber, int toAccountNumber, double amount) {

        BankAccount temp, temp2;

        temp = this.find(fromAccountNumber);
        temp2 = this.find(toAccountNumber);

        temp.withdraw(amount);
        temp2.deposit(amount);


    }
}