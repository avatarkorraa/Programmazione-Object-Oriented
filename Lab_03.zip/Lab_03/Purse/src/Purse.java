import java.util.ArrayList;
import java.util.List;

public class Purse {


    public final double dollar = 1;
    public final double quarter = 0.25;
    public final double dime = 0.10;
    public final double nickel = 0.05;
    public final double cent = 0.01;


    private final List<Coin> coins;

    public Purse() {
        coins = new ArrayList<>();
    }

    public void add(Coin coin) {
        coins.add(coin);
    }

    public boolean find(Coin coin){


        int i;

        for(i = 0; i < coins.size(); i++){

            if(coins.get(i).equals(coin))
                return true;

        }

        return false;


    }

    public int count(Coin coin) {


        int temp = 0;

        for(Coin c : coins){

            if(c.equals(coin))
                temp++;

        }

        return temp;


    }

    public Coin getMinimum() {


        int i;
        double temp;
        Coin minimo = coins.get(0);

        for(i = 0; i < coins.size(); i++){

            if(coins.get(i).getValue() < minimo.getValue()){

                minimo = coins.get(i);

            }

        }

        return minimo;


    }

    public Coin getMaximum() {


        int i;
        double temp;
        Coin massimo = coins.get(0);

        for(i = 0; i < coins.size(); i++){

            if(coins.get(i).getValue() > massimo.getValue()){

                massimo = coins.get(i);

            }

        }

        return massimo;


    }

    public double getTotal() {


        int i;
        double temp = 0;

        for(i = 0; i < coins.size(); i++)
            temp += coins.get(i).getValue();

        return temp;


    }

    public void remove(Coin coin) {


        int i;

        for(i = 0; i < coins.size(); i++){

            if(coins.get(i).equals(coin))
                coins.remove(i);

        }


    }

    public boolean hasCoin(Coin coin) {


        if(this.find(coin))
            return true;

        return false;


    }

    @Override
    public String toString() {


        Coin d = new Coin("Dollar", dollar), q = new Coin("Quarter", quarter),
                di = new Coin("Dime", dime), n = new Coin("Nickel", nickel),
                c = new Coin("Cent", cent);
        String stringa;

        int i;
        int nd, nq, ndi, nn, nc;

        nd = this.count(d);
        nq = this.count(q);
        ndi = this.count(di);
        nn = this.count(n);
        nc = this.count(c);

        stringa = new String("Purse[ Dollar = " + nd + " , Quarter = " + nq + " , Dime = " + ndi +
                                " , Nickel = " + nn + " , Cent = " + nc + " ]");

        return stringa;


    }

    @Override
    public boolean equals(Object o) {


        Coin d = new Coin("Dollar", this.dollar), q = new Coin("Quarter", this.quarter),
                di = new Coin("Dime", this.dime), n = new Coin("Nickel", this.nickel),
                c = new Coin("Cent", this.cent);

        if (this == o) return true;

        if (o == null || getClass() != o.getClass()) return false;

        Purse purse = (Purse) o;

        return purse.count(d) == this.count(d)
                && purse.count(q) == this.count(q)
                && purse.count(di) == this.count(di)
                && purse.count(n) == this.count(n)
                && purse.count(c) == this.count(c);


    }
}