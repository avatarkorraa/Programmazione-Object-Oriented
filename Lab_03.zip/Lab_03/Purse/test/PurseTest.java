import org.junit.Assert;
import org.junit.Test;

public class PurseTest {

  @Test
  public void findTest() {

    Purse purse = new Purse();
    Coin coin = new Coin("Dollar", purse.dollar);
    purse.add(coin);

    Assert.assertTrue(purse.find(coin));

  }

  @Test
  public void countTest() {

    Purse purse = new Purse();
    Coin coin = new Coin("Dollar", purse.dollar);
    purse.add(coin);

    Assert.assertEquals(1, purse.count(coin), 0);

  }

  @Test
  public void minMaxTest() {

    Purse purse = new Purse();
    Coin coin = new Coin("Dollar", purse.dollar), pippo = new Coin("Quarter", purse.quarter),
            pluto = new Coin("Dime", purse.dime);
    purse.add(coin);
    purse.add(pippo);
    purse.add(pluto);

    Assert.assertEquals(pluto, purse.getMinimum());
    Assert.assertEquals(coin, purse.getMaximum());

  }

  @Test
  public void getTotalTest() {

    Purse purse = new Purse();
    Coin coin = new Coin("Dollar", purse.dollar), pippo = new Coin("Quarter", purse.quarter),
            pluto = new Coin("Dime", purse.dime);
    purse.add(coin);
    purse.add(pippo);
    purse.add(pluto);

    Assert.assertEquals(1.35, purse.getTotal(), 0);

  }

  @Test
  public void addRemoveTest() {

    Purse purse = new Purse();
    Coin coin = new Coin("Dollar", purse.dollar), pippo = new Coin("Quarter", purse.quarter),
            pluto = new Coin("Dime", purse.dime);
    purse.add(coin);
    purse.add(pippo);
    purse.add(pluto);

    purse.remove(coin);
    Assert.assertFalse(purse.find(coin));
    Assert.assertEquals(pippo, purse.getMaximum());

  }

  @Test
  public void hasCoinTest() {

    Purse purse = new Purse();
    Coin coin = new Coin("Dollar", purse.dollar), pippo = new Coin("Quarter", purse.quarter),
            pluto = new Coin("Dime", purse.dime);
    purse.add(coin);
    purse.add(pippo);
    purse.add(pluto);

    Assert.assertTrue(purse.hasCoin(pippo));

  }

  @Test
  public void toStringTest() {

    Purse purse = new Purse();
    Coin coin = new Coin("Dollar", purse.dollar), pippo = new Coin("Quarter", purse.quarter),
            pluto = new Coin("Dime", purse.dime), paperino = new Coin("Nickel", purse.nickel),
            topolino = new Coin("Cent", purse.cent);

    purse.add(coin);
    purse.add(pippo);
    purse.add(pluto);
    purse.add(paperino);
    purse.add(topolino);

    Assert.assertEquals("Purse[ Dollar = 1 , Quarter = 1 , Dime = 1 , Nickel = 1 , Cent = 1 ]", purse.toString());

  }

  @Test
  public void equalsTest() {

    Purse purse = new Purse(), purse2 = new Purse();
    Coin coin = new Coin("Dollar", purse.dollar), pippo = new Coin("Quarter", purse.quarter),
            pluto = new Coin("Dime", purse.dime), paperino = new Coin("Nickel", purse.nickel),
            topolino = new Coin("Cent", purse.cent);

    purse.add(coin);
    purse.add(pippo);
    purse.add(pluto);
    purse.add(paperino);
    purse.add(topolino);

    purse2.add(coin);
    purse2.add(pippo);
    purse2.add(pluto);

    Assert.assertFalse(purse.equals(purse2));


  }
}