import org.junit.Assert;
import org.junit.Test;

public class TicTacToeTest {

    @Test
    public void horizontalWinTest() {

        TicTacToe nuovo = new TicTacToe();

        nuovo.set(0, 0, nuovo.player1);
        nuovo.set(0, 1, nuovo.player1);
        nuovo.set(0, 2, nuovo.player1);

        Assert.assertEquals(nuovo.player1, nuovo.getWinner());

    }

    @Test
    public void verticalWinTest() {

        TicTacToe nuovo = new TicTacToe();

        nuovo.set(0, 1, nuovo.player2);
        nuovo.set(1, 1, nuovo.player2);
        nuovo.set(2, 1, nuovo.player2);

        Assert.assertEquals(nuovo.player2, nuovo.getWinner());

    }

    @Test
    public void firstDiagonalWinTest() {

        TicTacToe nuovo = new TicTacToe();

        nuovo.set(0, 0, nuovo.player2);
        nuovo.set(1, 1, nuovo.player2);
        nuovo.set(2, 2, nuovo.player2);

        Assert.assertEquals(nuovo.player2, nuovo.getWinner());

    }

    @Test
    public void secondDiagonalWinTest() {

        TicTacToe nuovo = new TicTacToe();

        nuovo.set(0, 2, nuovo.player1);
        nuovo.set(1, 1, nuovo.player1);
        nuovo.set(2, 0, nuovo.player1);

        Assert.assertEquals(nuovo.player1, nuovo.getWinner());

    }

}