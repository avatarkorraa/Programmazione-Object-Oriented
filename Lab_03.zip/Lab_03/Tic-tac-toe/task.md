# Tic-tac-toe

Scrivere un metodo `getWinner` per la classe `TicTacToe` che restituisca `x`, `o` o `Nessun vincitore` a seconda se
vinca il giocatore `x`, il giocatore `o` o non ci sia nessun vincitore.

Scrivere un metodo `main` che esegua il gioco. Il programma disegna il tavolo da gioco, cambia il giocatore dopo ogni
mossa corretta, e visualizza il vincitore.