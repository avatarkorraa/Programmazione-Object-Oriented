import java.util.Random;
import java.util.Scanner;

public class Dice {

    public static void main(String[] args) {
        BankAccount playerAccount = new BankAccount(1000);
        BankAccount casinoAccount = new BankAccount(100000);
        int predictedValue, actualValue;
        double bet;
        String choice = "no";
        Scanner in = new Scanner(System.in);

        Random random = new Random();
        String flag;
        Scanner stringa = new Scanner(System.in);

        do {

            do {

                if (playerAccount.getBalance() == 0) {

                    System.out.println("IL TUO SALDO É PARI A 0");
                    return;

                }

                if (casinoAccount.getBalance() == 0) {

                    System.out.println("IL CASINO HA FINITO I FONDI!");
                    return;

                }

                System.out.println("Il tuo saldo ammonta a : " + playerAccount.getBalance() + " quanto vuoi scommettere?");
                bet = in.nextInt();

                if (bet > playerAccount.getBalance() || bet > casinoAccount.getBalance() * 5) {

                    System.out.println("IMPORTO NON SCOMMETTIBILE!");

                }

            } while (bet > playerAccount.getBalance() || bet > casinoAccount.getBalance() * 5);

            System.out.println("Quale numero scommetti che uscirà dal lancio?");
            predictedValue = in.nextInt();
            actualValue = random.nextInt(7);

            if (predictedValue == actualValue) {

                System.out.println("COMPLIMENTI!");
                casinoAccount.withdraw(bet);
                playerAccount.deposit(bet * 5);
                System.out.println("VINCITA: " + bet * 5);
            }

            if(predictedValue != actualValue) {

                System.out.println("MI DISPIACE!");
                playerAccount.withdraw(bet);
                casinoAccount.deposit(bet);
                System.out.println("PERDITA: " + bet);
            }

            System.out.println("Il tuo saldo è " + playerAccount.getBalance());
            System.out.println("Vuoi giocare ancora? (digita si se vuoi continuare)");
            flag = stringa.nextLine();

        }while(flag.equals("si"));

    }
}