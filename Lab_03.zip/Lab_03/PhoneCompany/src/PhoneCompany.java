import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class PhoneCompany {
    List<User> users;

    private final double minutePrice;
    private final double smsPrice;
    private final double gbPrice;

    public PhoneCompany(double minutePrice, double smsPrice, double gbPrice){

        users = new ArrayList<>();
        this.minutePrice = minutePrice;
        this.smsPrice = smsPrice;
        this.gbPrice = gbPrice;

    }

    public void readUserDataFromFile(File file)throws FileNotFoundException{

        Scanner sf;
        sf = new Scanner(file);
        int codiceUtente;
        String nome, cognome;

        while (sf.hasNextLine()) {

            codiceUtente = Integer.parseInt(sf.nextLine());
            nome = sf.nextLine();
            cognome = sf.nextLine();

            User utente = new User(codiceUtente, nome, cognome);

            utente.setUsedMinutes(Integer.parseInt(sf.nextLine()));
            utente.setUsedSMS(Integer.parseInt(sf.nextLine()));
            utente.setUsedMB(Double.parseDouble(sf.nextLine()));
            utente.setTotalCost(computeUserCost(utente));
            users.add(utente);

        }

    }

    public User findUserByCode(int codiceUtente) {

        for(User utente : users){

            if(utente.getCode() == codiceUtente)
                return utente;

        }

        return null;

    }

    public double computeUserCost(User user){

        double costoTotale;

        costoTotale = (user.getUsedMinutes() * minutePrice) + (user.getUsedSMS() * smsPrice) + (user.getUsedMB() / 1000 * gbPrice);

        return costoTotale;
    }

}
