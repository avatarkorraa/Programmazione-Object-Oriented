import org.junit.Assert;
import org.junit.Test;

public class CarTest {

    @Test

    public void TestGas(){

        Car nuova = new Car(1.0);

        Assert.assertEquals(0, nuova.getGas(), 0);

    }

    @Test

    public void TestGasDue(){

        Car nuova = new Car(0.1);

        nuova.addGas(30);

        Assert.assertEquals(30, nuova.getGas(), 0);


    }

    @Test

    public void TestGasTre(){

        Car nuova = new Car(2.0);

        nuova.addGas(2);

        nuova.drive(1);

        Assert.assertEquals(0, nuova.getGas(), 0);

    }
}