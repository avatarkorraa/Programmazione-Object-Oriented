import org.junit.Assert;
import org.junit.Test;

public class InputCheckerTest {

    @Test

    public void TestInput1(){

        InputChecker inputchecker = new InputChecker();
        Assert.assertEquals(inputchecker.checkInput("No"), "Fine");

    }

    @Test

    public void TestInput2(){

        InputChecker inputchecker = new InputChecker();
        Assert.assertEquals(inputchecker.checkInput("S"), "OK");

    }

    @Test

    public void TestInput3(){

        InputChecker inputchecker = new InputChecker();
        Assert.assertEquals(inputchecker.checkInput("La casa blu"), "Dato non corretto");

    }

}