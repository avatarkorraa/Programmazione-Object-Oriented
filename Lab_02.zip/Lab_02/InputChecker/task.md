# InputChecker

Implementare e testare una classe `InputChecker` che contenga un metodo `checkInput(String)` che stampi

1. "OK” se legge "S” ,”SI”, "OK”, "certo” oppure "perchè no?”.
2. "Fine” se legge "N” o "No”
3. "Dato non corretto" altrimenti
