import java.util.Scanner;

public class InputChecker {

    public String checkInput(String input) {

        char a = input.charAt(0);

        switch(a){

            case 'S': if(input.equals("S") || input.equals("SI")) return"OK";
            case 'O': if(input.equals("OK")) return "OK";
            case 'c': if(input.equals("certo")) return "OK";
            case 'p': if(input.equals("perchè no?")) return "OK";
            case 'N': if(input.equals("N") || input.equals("No")) return "Fine";
            default: return "Dato non corretto";
        }

    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        System.out.println("Dammi l'input di verifica: ");
        String input = in.nextLine();

        InputChecker inputChecker = new InputChecker();
        System.out.println(inputChecker.checkInput(input));
    }
}