import org.junit.Assert;
import org.junit.Test;

public class InfectedTest {

    @Test

    public void TestInfetti(){

        Infected infetti = new Infected("Covid19");

        Assert.assertEquals(0, infetti.getNumberOfInfected(), 0);
        Assert.assertEquals("Covid19", infetti.getDisease());

    }

    @Test

    public void TestInfettiDue(){

        Infected infetti = new Infected("Influenza", 20);

        Assert.assertEquals(20, infetti.getNumberOfInfected(), 0);

        infetti.addInfected(19);

        Assert.assertEquals(39, infetti.getNumberOfInfected(), 0);

    }

    @Test

    public void TestInfettiTre(){

        Infected infetti = new Infected("Vomito", 3);
        double Rt = 5;

        Assert.assertEquals(3, infetti.getNumberOfInfected(), 0);

        infetti.updateInfectedByRt(Rt);

        Assert.assertEquals(15, infetti.getNumberOfInfected(), 0);

    }
}