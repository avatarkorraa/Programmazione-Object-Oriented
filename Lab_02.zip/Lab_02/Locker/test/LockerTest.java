import org.junit.Assert;
import org.junit.Test;

public class LockerTest {

    @Test

    public void LockerTest1(){

        Locker newlocker = new Locker();

        Assert.assertTrue(newlocker.isOpen());

    }

    @Test

    public void Lockertest2() {

        Locker newlocker = new Locker();

        newlocker.lock();
        newlocker.unlock("");

        Assert.assertTrue(newlocker.isOpen());


    }

    @Test

    public void Lockertest3(){

        Locker newlocker = new Locker();

        newlocker.lock();
        newlocker.newComb("PASSWORD");
        newlocker.unlock("PASSWORD");

        Assert.assertTrue(newlocker.isOpen());

    }

}