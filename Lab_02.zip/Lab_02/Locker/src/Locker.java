public class Locker {

    private boolean isOpen;
    private String code;

    public Locker() {
        isOpen = true;
        code = "";
    }

    public void unlock(String code) {

        if(this.code.compareTo(code) == 0)
            this.isOpen = true;

        else
            this.isOpen = false;

    }

    public boolean isOpen() {

        return this.isOpen;

    }

    public void lock() {

        this.isOpen = false;

    }

    public void newComb(String newCode) {

        this.code = newCode;

    }

}