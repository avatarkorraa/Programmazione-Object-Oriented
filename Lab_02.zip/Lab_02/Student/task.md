# Studente

Esercizio come il precedente rispetto però ad una classe `Student` dove siamo interessati a registrare i voti degli
esami
di uno studente e recuperare il voto medio.