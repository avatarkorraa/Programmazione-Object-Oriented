import org.junit.Assert;
import org.junit.Test;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class StudentTest {

    @Test

    public void testExam(){

        String nome = "Antonio", cognome = "Napaperipluto";
        GregorianCalendar data = new GregorianCalendar(2022, Calendar.MAY, 12);
        Exam exam = new Exam("scienze delle mandorle",  data, 30);
        Student studente = new Student(nome, cognome);
        studente.registerExam(exam);

        Assert.assertEquals(1, studente.getExams().size(), 0);
        Assert.assertEquals(30, studente.computeAverageGrade(), 0);

    }

    @Test

    public void nameSurnameTest(){

        String nome = "Mario", cognome = "nappi";
        Student studente = new Student(nome, cognome);

        Assert.assertEquals(nome, studente.getFirstName());
        Assert.assertEquals(cognome, studente.getLastName());
        Assert.assertTrue(studente.getExams().isEmpty());

    }

    @Test

    public void testDueEsami(){

        String nome = "Nicola", cognome = "Pluto";
        GregorianCalendar data = new GregorianCalendar(2020, Calendar.SEPTEMBER, 27);
        GregorianCalendar data2 = new GregorianCalendar(2024, Calendar.JUNE, 23);
        Student studente = new Student(nome, cognome);

        Exam primo = new Exam("Programmazione", data, 24);
        studente.registerExam(primo);

        Exam secondo = new Exam("Metodi Matematici per l'informatica", data2, 30);
        studente.registerExam(secondo);

        Assert.assertEquals(2, studente.getExams().size(), 0);
        Assert.assertEquals(27, studente.computeAverageGrade(), 0);

    }

}