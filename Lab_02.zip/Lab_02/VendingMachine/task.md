# Distributore di bibite

Un distributore di bibite contiene lattine di bibite.

Per comprare una bibita il cliente deve inserire un gettone.
Quando il gettone è inserito, una lattina cade nel contenitore dove può essere presa dal cliente.

Il distributore può essere riempito con ulteriori lattine.
Vogliamo determinare quante lattine e gettoni sono presenti nella macchina ad un dato istante.

Implementare e testare la classe ottenuta.