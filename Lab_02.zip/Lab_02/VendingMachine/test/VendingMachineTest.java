import org.junit.Assert;
import org.junit.Test;

public class VendingMachineTest {

  @Test
  public void TestCaseOne(){

      VendingMachine test = new VendingMachine();

      Assert.assertEquals(0, test.getNumberOfCans(), 0);

      test.addCans(100);

      Assert.assertEquals(100, test.getNumberOfCans(), 0);

  }

  @Test
    public void TestCaseTwo(){

      VendingMachine testdue = new VendingMachine(100);

      int temp;

      for(temp = 0; temp < 99; temp++) {

        testdue.takeCan();

      }

      Assert.assertEquals(1, testdue.getNumberOfCans(), 0);
      Assert.assertEquals(99, testdue.getNumberOfTokens(), 0);

  }

}