# Libretto di risparmio

Scrivere la classe `SavingsAccount` che è del tutto simile alla classe `BankAccount`, tranne che per una variabile di
istanza aggiuntiva, `interestRate` (tasso di interesse annuo).

Fornire, oltre a tutti i metodi della classe `BankAccount`:

* un metodo costruttore che imposti sia il saldo iniziale che il tasso di interesse;
* un metodo addInterest che aggiunge gli interessi trimestrali al conto.