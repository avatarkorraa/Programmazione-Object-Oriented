import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class FirstAndLastWordTest{

   @Test

    public void TestFirstAndLastWord1(){

        List <String> newList = new ArrayList<>();
        newList.add("a");
        newList.add("z");
        newList.add("c");
        FirstAndLastWord nuova = new FirstAndLastWord(newList);

        nuova.sort();
        Assert.assertEquals("a", nuova.getFirst());
        Assert.assertEquals("z", nuova.getLast());

    }

    @Test

    public void TestFirstAndLastWord(){

       List <String> newList = new ArrayList<>();
       newList.add("R");
       newList.add("a");
       newList.add("Z");
       newList.add("AAA");
       FirstAndLastWord nuova = new FirstAndLastWord(newList);

       nuova.sortIgnoreCase();
       Assert.assertEquals("a", nuova.getFirst());
       Assert.assertEquals("Z", nuova.getLast());


    }

}