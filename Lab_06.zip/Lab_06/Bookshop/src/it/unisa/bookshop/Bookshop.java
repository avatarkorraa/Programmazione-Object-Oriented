package it.unisa.bookshop;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class Bookshop {

    final private List<Book> bookshop;

    public Bookshop() {
        bookshop = new ArrayList<>();
    }

    public List<Book> findByAuthor(String author) {

        List<Book> result = new ArrayList<>();

        for (Book c : bookshop) {

            if (c.getAuthor().equals(author))
                result.add(c);

        }

        return result;

    }

    public List<Book> findByTitleContent(String titleContent) {

        List<Book> result = new ArrayList<>();

        for (Book c : bookshop) {

            if (c.getTitle().lastIndexOf(titleContent) != -1)
                result.add(c);

        }

        return result;

    }

    public List<Book> findMaxAvailable() {

        List<Book> result = new ArrayList<>();
        int max;

        max = bookshop.get(0).getNumberOfCopies();

        for (Book c : bookshop) {

            if (c.getNumberOfCopies() > max)
                max = c.getNumberOfCopies();

        }

        for (Book c : bookshop) {

            if (c.getNumberOfCopies() == max)
                result.add(c);

        }

        return result;

    }

    public List<Book> findBelowAvailability(int threshold) {

        List<Book> result = new ArrayList<>();

        for (Book c : bookshop) {

            if (threshold > c.getNumberOfCopies())
                result.add(c);

        }

        return result;

    }

    public List<Book> getBookshop() {
        return bookshop;
    }

    public void readUserDataFromFile(File file) throws FileNotFoundException {

        Scanner fileScanner = new Scanner(file);
        String title, author, editor;
        int numCopies;

        while(fileScanner.hasNextLine()){

            title = fileScanner.nextLine();
            author = fileScanner.nextLine();
            editor = fileScanner.nextLine();
            numCopies = Integer.parseInt(fileScanner.nextLine());

            Book book = new Book(title, author, editor);
            book.setNumberOfCopies(numCopies);

            bookshop.add(book);

        }

    }

}