package it.unisa.bookshop;

import org.junit.Assert;
import org.junit.Test;

import java.io.File;
import java.io.FileNotFoundException;
import java.nio.file.Path;
import java.util.List;

public class BookshopTest {

    @Test
    public void readLibraryTest() throws FileNotFoundException {

        File file = Path.of("test/").resolve("libreria.txt").toFile();
        Bookshop bookshop = new Bookshop();

        bookshop.readUserDataFromFile(file);

        Assert.assertEquals(5, bookshop.getBookshop().size(), 0);


    }

    @Test
    public void findByAuthorTest() throws FileNotFoundException {

        File file = Path.of("test/").resolve("libreria.txt").toFile();
        Bookshop bookshop = new Bookshop();
        List<Book> result;

        bookshop.readUserDataFromFile(file);
        result = bookshop.findByAuthor("Mario Nappi");

        Assert.assertEquals(1, result.size(), 0);

    }

    @Test
    public void findByTitleContentTest() throws FileNotFoundException {

        File file = Path.of("test/").resolve("libreria.txt").toFile();
        Bookshop bookshop = new Bookshop();
        List<Book> result;

        bookshop.readUserDataFromFile(file);
        result = bookshop.findByTitleContent("Se");

        Assert.assertEquals(1, result.size(), 0);

    }

    @Test
    public void findMaxAvailabilityTest() throws FileNotFoundException {

        File file = Path.of("test/").resolve("libreria.txt").toFile();
        Bookshop bookshop = new Bookshop();
        List<Book> result;

        bookshop.readUserDataFromFile(file);
        result = bookshop.findMaxAvailable();

        Assert.assertEquals(2, result.size(), 0);

    }

    @Test
    public void findBelowAvailabilityTest() throws FileNotFoundException {

        File file = Path.of("test/").resolve("libreria.txt").toFile();
        Bookshop bookshop = new Bookshop();
        List<Book> result;

        bookshop.readUserDataFromFile(file);
        result = bookshop.findBelowAvailability(20);

        Assert.assertEquals(2, result.size(), 0);

    }

}