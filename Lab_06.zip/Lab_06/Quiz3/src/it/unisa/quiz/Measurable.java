package it.unisa.quiz;

public interface Measurable extends Comparable<Measurable>{
    double getMeasure();
}