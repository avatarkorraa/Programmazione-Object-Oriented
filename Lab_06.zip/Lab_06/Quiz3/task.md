# Quiz 3

Modificare l’interfaccia `Measurable` in modo che estenda l’interfaccia `Comparable<Measurable>`.

In seguito modificare la classe `Quiz` in modo che sovrascriva i metodi dell’interfaccia `Measurable`.

La nuova classe `DataSet` deve fornire le stesse funzionalità mostrate precedentemente e va testata allo stesso modo.