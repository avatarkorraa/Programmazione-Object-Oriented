# Banca 2

Riprogettare e testare la gerarchia di classi `BankAccount` e `SavingsAccount` in modo che `SavingsAccount`
estenda `BankAccount`.

Analizzare i casi di test, notando le istanze del principio di sostituzione di Liskov.