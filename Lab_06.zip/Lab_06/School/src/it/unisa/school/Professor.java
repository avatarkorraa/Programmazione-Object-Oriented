package it.unisa.school;

public class Professor extends Person {

    private String topic;
    private float wage;


    public Professor(String nome, String cognome, int anno, String topic, int wage){

        super(nome, cognome, anno);
        this.topic = topic;
        this.wage = wage;


    }

    public float getWage(){

        return this.wage;

    }

    public String getTopic(){

        return this.topic;

    }

    public void setTopic(String topic){

        this.topic = topic;

    }

    public void setWage(float wage){

        this.wage = wage;

    }

    @Override
    public String toString() {
        return super.toString() +
                ", Argomento='" + topic + '\'' +
                ", Stipendio=" + wage;
    }
}
