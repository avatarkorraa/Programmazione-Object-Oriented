package it.unisa.school;

public class Student extends Person {

    private int numberOfAbsences;

    public Student(String nome, String cognome, int anno, int nAssenze){

        super(nome, cognome, anno);
        this.numberOfAbsences = nAssenze;

    }

    public int getNumberOfAbsences(){

        return this.numberOfAbsences;

    }

    public void addAbsences(int n){

        numberOfAbsences += n;

    }

    public void subtractAbsences(int n){

        numberOfAbsences -= n;

        if(numberOfAbsences < 0)
            numberOfAbsences = 0;

    }

    @Override
    public String toString() {
        return super.toString() +
                ", Numero di assenze=" + numberOfAbsences;
    }
}
