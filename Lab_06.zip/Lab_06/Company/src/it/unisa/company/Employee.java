package it.unisa.company;

public class Employee extends Staff {

    private String jobTitle;
    private float hourlyWage;

    public Employee(String nome, String cognome, String jobTitle, float hourlyWage){

        super(nome, cognome);
        this.jobTitle = jobTitle;
        this.setHourlyWage(hourlyWage);

    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public float getHourlyWage() {
        return hourlyWage;
    }

    public void setHourlyWage(float hourlyWage){

        this.hourlyWage = hourlyWage;
        updateSalary(this.getHourlyWage());

    }


    public void updateSalary(float hourlyWage){


        super.setWage(40 * hourlyWage);

    }

    @Override
    public String toString() {
        return super.toString() +
                ", Incarico='" + jobTitle + '\'';
    }
}
