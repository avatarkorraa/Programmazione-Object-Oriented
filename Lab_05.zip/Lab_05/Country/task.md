# Nazione

Creare una classe `Country` che implementi l’interfaccia `Comparable`.
Una nazione ha un nome e una superficie.
Il metodo `compareTo` deve confrontare due nazioni in base alla superficie del loro territorio.

Usare la classe `DataSet` creata nell’esercizio precedente.
Si testi il tutto aggiungendo un certo numero di oggetti di tipo `Country` restituendo il nome e la superficie della
nazione con la superficie maggiore e quello con la superficie minore.

Il metodo `getAverage()` non ha senso in questo esercizio e può essere rimosso.