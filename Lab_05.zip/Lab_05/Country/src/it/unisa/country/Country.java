package it.unisa.country;

public class Country implements Comparable {

    final private String name;
    final private double surfaceArea;

    public Country(String name, double surfaceArea) {
        this.name = name;
        this.surfaceArea = surfaceArea;
    }

    public String getName() {
        return name;
    }

    public double getSurfaceArea() {
        return surfaceArea;
    }

    @Override

    public int compareTo(Object obj){

        Country country = (Country) obj;

        if(this.surfaceArea - country.getSurfaceArea() < 0)
            return -1;

        if(this.surfaceArea - country.getSurfaceArea() > 0)
            return 1;

        return 0;

    }

}