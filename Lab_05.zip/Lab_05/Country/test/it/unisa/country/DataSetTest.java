package it.unisa.country;

import org.junit.Assert;
import org.junit.Test;

public class DataSetTest {
    @Test
    public void testMinimum() {

        Country country = new Country("Italia", 301.230);
        Country country2 = new Country("Inghilterra", 130.279);
        Country country3 = new Country("Francia", 543.940);
        DataSet dataset = new DataSet();

        dataset.add(country);
        dataset.add(country2);
        dataset.add(country3);

        Assert.assertEquals("Inghilterra", dataset.getMinimum().getName());

    }

    @Test
    public void testMaximum() {

        Country country = new Country("Italia", 301.230);
        Country country2 = new Country("Inghilterra", 130.279);
        Country country3 = new Country("Francia", 543.940);
        DataSet dataset = new DataSet();

        dataset.add(country);
        dataset.add(country2);
        dataset.add(country3);

        Assert.assertEquals("Francia", dataset.getMaximum().getName());

    }
}