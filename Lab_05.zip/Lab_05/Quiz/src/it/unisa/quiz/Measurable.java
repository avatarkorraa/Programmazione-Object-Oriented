package it.unisa.quiz;

public interface Measurable {
    double getMeasure();
}