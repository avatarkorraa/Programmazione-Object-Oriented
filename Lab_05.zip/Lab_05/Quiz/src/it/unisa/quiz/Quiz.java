package it.unisa.quiz;

public class Quiz implements Measurable {
    public final double voto;

    public Quiz(double voto){

        this.voto = voto;

    }

    @Override

    public double getMeasure(){

        return voto;

    }

}
