# SMS

Riprogettare e testare le classi `SMS` e `SMSOrganizers` aggiungendo a `SMS` due variabili statiche di tipo `Comparator`
che permettano di ordinare gli SMS per data e mittente.