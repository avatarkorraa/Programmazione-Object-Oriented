package it.unisa.quiz;

import org.junit.Assert;
import org.junit.Test;

public class DataSetTest {
    @Test
    public void testMinimum() {

        Quiz nuovo = new Quiz(30);
        Quiz nuovo2 = new Quiz(27);
        DataSet dataset = new DataSet();

        dataset.add(nuovo);
        dataset.add(nuovo2);

        Assert.assertEquals(27, dataset.getMinimum().getMeasure(), 0);

    }

    @Test
    public void testMaximum() {

        Quiz nuovo = new Quiz(30);
        Quiz nuovo2 = new Quiz(27);
        DataSet dataset = new DataSet();

        dataset.add(nuovo);
        dataset.add(nuovo2);

        Assert.assertEquals(30, dataset.getMaximum().getMeasure(), 0);

    }

    @Test
    public void testAverage() {

        Quiz nuovo = new Quiz(30);
        Quiz nuovo2 = new Quiz(27);
        DataSet dataset = new DataSet();

        dataset.add(nuovo);
        dataset.add(nuovo2);

        Assert.assertEquals(28.5, dataset.getAverage(), 0);

    }
}