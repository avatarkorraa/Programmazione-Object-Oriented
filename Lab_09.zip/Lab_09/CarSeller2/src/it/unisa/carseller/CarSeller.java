package it.unisa.carseller;

import java.io.*;
import java.nio.file.FileAlreadyExistsException;
import java.util.*;

public class CarSeller {
    private List<Car> cars;


    public CarSeller() {
        this.cars = new ArrayList<>();
    }

    public void readUserDataFromFile(File file) throws FileNotFoundException {

        try{

            Scanner in = new Scanner(file);

            while(in.hasNextLine()) {

                String brand, model;
                int anno;
                double prezzo;

                brand = in.nextLine();
                model = in.nextLine();
                anno = Integer.parseInt(in.nextLine());
                prezzo = Double.parseDouble(in.nextLine());

                cars.add(new Car(brand, model, anno, prezzo));

            }

        }catch(NoSuchElementException | NumberFormatException e){

            System.out.println("File format error! exit!");
            e.printStackTrace();

        }

    }

    public void writeUserDataToFile(File file, boolean overwrite) throws FileNotFoundException, FileAlreadyExistsException {

        if(!overwrite){

            if(file.exists())
                throw new FileAlreadyExistsException("File già esistente!");
            else{
                writeUserDataToFile(file);
            }
        }
        else{

            String tmpFileName = file.getParentFile().getName() + File.separator + "tmp_" + file.getName();
            File tmpFile = new File(tmpFileName);
            writeUserDataToFile(tmpFile);
            file.delete();
            tmpFile.renameTo(file);

        }


    }

    public void writeUserDataToFile(File file) throws FileNotFoundException, FileAlreadyExistsException{

        PrintWriter pr = new PrintWriter(file);

        for(Car c : cars){

            pr.println(c.getBrand());
            pr.println(c.getModel());
            pr.println(c.getManufacturingYear());
            pr.println(c.getPrice());

        }

        pr.close();

    }

    @SuppressWarnings("unchecked")
    public void readSerializedDataFromFile(File file) throws IOException, ClassNotFoundException{

        ObjectInputStream in = new ObjectInputStream(new FileInputStream(file));
        this.cars = (List<Car>) in.readObject();
        in.close();

    }

    public List<Car> getCars() {
        return cars;
    }

    public void writeSerializedDataToFile(File file) throws IOException {

        ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(file));
        output.writeObject(this.cars);
        output.close();

    }

    public List<Car> returnCarByBrandAndModel(String brand, String model) {
        List<Car> suitableCars = new ArrayList<>();
        for (Car car : this.cars) {
            if (car.getBrand().equals(brand) && car.getModel().equals(model)) {
                suitableCars.add(car);
            }
        }
        return suitableCars;
    }

    public List<Car> returnCarByBrandModelAndYear(String brand, String model, int manufacturingYear) {
        List<Car> suitableCars = new ArrayList<>();
        for (Car car : this.cars) {
            if (car.getBrand().equals(brand)
                    && car.getModel().equals(model)
                    && car.getManufacturingYear() >= manufacturingYear) {
                suitableCars.add(car);
            }
        }
        return suitableCars;
    }

    public List<Car> returnCarByBrandAModelYearAndPrice(String brand, String model, int manufacturingYear, int minPrice, int maxPrice) {
        List<Car> suitableCars = new ArrayList<>();
        for (Car car : this.cars) {
            if (car.getBrand().equals(brand)
                    && car.getModel().equals(model)
                    && car.getManufacturingYear() >= manufacturingYear
                    && car.getPrice() >= minPrice
                    && car.getPrice() <= maxPrice) {
                suitableCars.add(car);
            }
        }
        return suitableCars;
    }
}