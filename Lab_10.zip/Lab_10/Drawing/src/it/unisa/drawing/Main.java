package it.unisa.drawing;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.*;

public class Main {
    public static void main(String[] args) {
        JFrame frame = new JFrame();
        final int FRAME_WIDTH = 300;
        final int FRAME_HEIGHT = 300;
        frame.setSize(FRAME_WIDTH, FRAME_HEIGHT);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        JComboBox comboBox = new JComboBox();
        comboBox.addItem("Circonferenza");
        comboBox.addItem("Due cerchi");
        comboBox.addItem("Una Grande Ellissi");
        JButton jbutton = new JButton("AVANTI");
        ActionListener actionListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String item = (String) comboBox.getSelectedItem();

                if(item.equals("Circonferenza")){

                    String input = JOptionPane.showInputDialog("Inserisci raggio");
                    frame.setVisible(false);
                    float raggio = Float.parseFloat(input);
                    CircleComponent CircleComponent = new CircleComponent(raggio, 112, 112);

                    panel.add(CircleComponent);
                    frame.setVisible(true);

                }

                else if(item.equals("Due cerchi")){
                    frame.setVisible(false);
                    CircleComponent CircleComponent = new CircleComponent(Color.red, Color.red , 45, 65, 80);
                    CircleComponent CircleTwo = new CircleComponent(new Color(155, 10, 150),
                            new Color(155, 10, 150), 45, 30, 30);

                    panel.add(CircleComponent);
                    panel.repaint();
                    panel.validate();
                    panel.add(CircleTwo);
                    frame.setVisible(true);

                }

                else if(item.equals("Una Grande Ellissi")){

                    frame.setVisible(false);

                    CircleComponent CircleComponent = new CircleComponent(Color.BLUE, Color.BLUE, frame.getWidth(), 0, 0);

                    ComponentListener l = new ComponentListener() {
                        @Override
                        public void componentResized(ComponentEvent e) {
                            CircleComponent.setSize(frame.getWidth(), frame.getHeight());
                        }

                        @Override
                        public void componentMoved(ComponentEvent e) {

                        }

                        @Override
                        public void componentShown(ComponentEvent e) {

                        }

                        @Override
                        public void componentHidden(ComponentEvent e) {

                        }
                    };

                    frame.addComponentListener(l);

                    panel.add(CircleComponent);

                    frame.setVisible(true);


                }

            }
        };
        jbutton.addActionListener(actionListener);
        panel.add(jbutton, BorderLayout.SOUTH);
        panel.add(comboBox, BorderLayout.NORTH);
        frame.add(panel);

        frame.setVisible(true);

    }
}