# Disegnare

Scrivere un’applicazione che chieda in input cosa voglia disegnare.
Se si seleziona la prima opzione, l’applicazione chiede all’utente di inserire la misura di un raggio e traccia una
circonferenza con quel raggio.

Se si seleziona la seconda opzione, l’applicazione disegna due cerchi pieni, uno rosa e uno viola. Usate un colore
standard per uno e uno personalizzato per l’altro.

Scrivere un’applicazione che disegni una grande ellisse, che
tocchi i bordi della finestra dell’applet
sia riempita con il vostro colore preferito
si ridimensioni automaticamente quando si ridimensiona la finestra
Utilizzare i metodi `getWidth()` e `getHeight()` per calcolare le dimensioni della finestra.