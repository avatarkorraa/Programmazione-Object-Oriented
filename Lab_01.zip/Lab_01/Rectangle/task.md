# La classe `Rectangle`

Scrivere un programma che istanzi un oggetto `Rectangle` e lo stampi.

Modificare il programma in modo che sposti il rettangolo stampato di `movX` e `movY` ed aggiunga 3 rettangoli in
orizzontale cosí che se i 4 rettangoli stampati fossero disegnati, formerebbero un unico grande rettangolo.

Infine, stampare le caratteristiche del rettangolo finale con area e perimetro.