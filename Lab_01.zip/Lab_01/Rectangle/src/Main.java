import java.awt.*;

public class Main {
    public static void main(String[] args) {
        int x = 0;
        int y = 0;
        int width = 10;
        int height = 20;

        int newX = 5;
        int newY = 5;

        double area;
        double perimeter;

        Rectangle rectangle = new Rectangle(x, y, width, height);
        rectangle.add(newX, newY);
        Rectangle r1, r2, r3;

        x += width + newX;
        r1 = new Rectangle(x, newY, width, height);
        x += width;
        r2 = new Rectangle(x, newY, width, height);
        x += width;
        r3 = new Rectangle(x, newY, width, height);

        x += newX;
        Rectangle box = new Rectangle(newX, newY, x, height);
        area = box.getWidth() * box.getHeight();
        perimeter = (box.getWidth() + box.getHeight()) * 2;

        System.out.println(box);
        System.out.println(area);
        System.out.println(perimeter);

    }
}