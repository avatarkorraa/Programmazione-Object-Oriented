public class Main {
    public static void main(String[] args) {
        String[] words = {"", "a", "alice", "bob", "pippo", "pluto"};

        for (String word : words) {
            String result = "", t = "", temp = "";
            char c;

            if(word.length() > 0){

                c = word.charAt(0);
                t = t + c;
                t = t.toUpperCase();
                temp = temp + c;
                result = word.replaceFirst(temp, t);

            }

            System.out.println(result);

        }
    }
}