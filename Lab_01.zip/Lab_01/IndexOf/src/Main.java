public class Main {
    public static void main(String[] args) {
        String[] words = {"", "a", "sasso", "pippo", "test"};

        for (String word : words) {
            int position = -1;
            if(word.length() > 2){

                String first = word.substring(0, 1);

                position = word.indexOf(first, 1);

            }
            System.out.println(position);
        }
    }
}