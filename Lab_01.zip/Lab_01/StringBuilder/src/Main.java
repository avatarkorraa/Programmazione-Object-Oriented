public class Main {
    public static void main(String[] args) {
        String sentence = "Hello, World!";
        StringBuilder newSentence = new StringBuilder();

        sentence = sentence.replace("o", "e");

        sentence = sentence.replaceFirst("e", "o");

        newSentence.insert(0, sentence);

        System.out.println(newSentence);
    }
}