# Invertire la prima e l'ultima lettera di una stringa

Scrivere un programma che data una stringa di almeno 2 caratteri, ne costruisca un’altra dove il primo carattere è
scambiato con l’ultimo, che viene poi stampata a video.

Se la stringa è troppo corta si stampi `Stringa corta`.